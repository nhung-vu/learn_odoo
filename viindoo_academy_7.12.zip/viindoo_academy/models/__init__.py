# -*- coding: utf-8 -*-

from . import education_student
from . import education_class
from . import viin_vip_academy
from . import education_class2
from . import education_student2
from . import ethnicity